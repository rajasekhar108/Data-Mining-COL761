g++ -std=c++11 convertdata_fsg.cpp -o convertdatafsg
g++ -std=c++11 convertdata_gaston.cpp -o convertdatagaston
g++ -std=c++11 convertdata_gspan.cpp -o convertdatagspan

./convertdatagaston 167.txt_graph gastondata.dat
./convertdatagspan 167.txt_graph gspandata.dat
./convertdatafsg 167.txt_graph fsgdata.dat
data=()

start_time=$(date +%s)
./gaston 60904.5 gastondata.dat -p
end_time=$(date +%s)
data[0]=$((end_time - start_time))

start_time=$(date +%s)
./gaston 32055 gastondata.dat -p
end_time=$(date +%s)
data[1]=$((end_time - start_time))

start_time=$(date +%s)
./gaston 16027.5 gastondata.dat -p
end_time=$(date +%s)
data[2]=$((end_time - start_time))

start_time=$(date +%s)
./gaston 6411 gastondata.dat -p
end_time=$(date +%s)
data[3]=$((end_time - start_time))

start_time=$(date +%s)
./gaston 3205.5 gastondata.dat -p
end_time=$(date +%s)
data[4]=$((end_time - start_time))



start_time=$(date +%s)
./gSpan-64 -f gspandata.dat -s 0.95 -o -i
end_time=$(date +%s)
data[5]=$((end_time - start_time))

start_time=$(date +%s)
./gSpan-64 -f gspandata.dat -s 0.50 -o -i
end_time=$(date +%s)
data[6]=$((end_time - start_time))

start_time=$(date +%s)
./gSpan-64 -f gspandata.dat -s 0.25 -o -i
end_time=$(date +%s)
data[7]=$((end_time - start_time))

start_time=$(date +%s)
./gSpan-64 -f gspandata.dat -s 0.10 -o -i
end_time=$(date +%s)
data[8]=$((end_time - start_time))

start_time=$(date +%s)
./gSpan-64 -f gspandata.dat -s 0.05 -o -i
end_time=$(date +%s)
data[9]=$((end_time - start_time))


start_time=$(date +%s)
./fsg -s 95.0 -pt fsgdata.dat
end_time=$(date +%s)
data[10]=$((end_time - start_time))

start_time=$(date +%s)
./fsg -s 50.0 -pt fsgdata.dat
end_time=$(date +%s)
data[11]=$((end_time - start_time))

start_time=$(date +%s)
./fsg -s 25.0 -pt fsgdata.dat
end_time=$(date +%s)
data[12]=$((end_time - start_time))

start_time=$(date +%s)
./fsg -s 10.0 -pt fsgdata.dat
end_time=$(date +%s)
data[13]=$((end_time - start_time))

start_time=$(date +%s)
./fsg -s 5.0 -pt fsgdata.dat
end_time=$(date +%s)
data[14]=$((end_time - start_time))

python3 plot.py "${data[@]}" "$1"

