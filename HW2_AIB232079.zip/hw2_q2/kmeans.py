
import sys

from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
dim = sys.argv[2]
ls = []
path = sys.argv[1]
with open(path,'r') as file:
  for line in file:
    if '\n' in line:
      line[:-2]
    ls.append(line.split(' '))

clusters = 16
inetr_val = []

for i in range(1,clusters):
  kmeans = KMeans(n_clusters=i)
  kmeans.fit(ls)
  inetr_val.append(kmeans.inertia_)

cluster_labels = kmeans.labels_
cluster_centroids = kmeans.cluster_centers_



plt.figure(figsize=(8, 6))
plt.plot(range(1,clusters), inetr_val, marker='o', linestyle='-', color='b')
plt.xlabel('Number of Clusters (K)')
plt.ylabel('Inertia')
plt.title("Elbow plot")
plt.savefig(sys.argv[3])
plt.grid(True)
plt.show()
