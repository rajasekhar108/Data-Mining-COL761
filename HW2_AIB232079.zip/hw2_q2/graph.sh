#!/bin/bash
python3 kmeans.py "$1" "$2" "$3"

