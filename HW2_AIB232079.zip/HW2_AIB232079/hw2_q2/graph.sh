#!/bin/bash
./generateDataset_d_dim_hpc_compiled AIB232079 "$2"
python3 kmeans.py "$1" "$2" "$3"

