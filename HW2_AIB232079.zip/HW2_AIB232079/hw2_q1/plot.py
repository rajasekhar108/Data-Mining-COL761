import matplotlib.pyplot as plt
import sys

args = sys.argv[1:16]
y = [int(arg) for arg in args]
y1=y[:5]
y2=y[5:10]
y3=y[10:]
x1=[95,50,25,10,5]
plt.figure(figsize=(8, 6))

plt.plot(x1, y1, label='gaston', marker='o')
plt.plot(x1, y2, label='gspan', marker='s')
plt.plot(x1, y3, label='fsg', marker='^')

plt.title('plots of fsg,gaston and gspan')
plt.xlabel('support')
plt.ylabel('Time in sec')
plt.legend()
plt.grid(True)
plt.savefig("AIB232079.png")
