#include<bits/stdc++.h>
using namespace std;





vector<int> getdata(string s )
{
    vector<int> data;
    istringstream iss(s);
    int token;
    while (iss >> token) {
        data.push_back(token);
    }
    return data;
}


void givealllines(FILE *f,list<string>&alllines)
{
    string line;

    while (true) {
        int ch = getc_unlocked(f);
        if (ch == EOF) {
            if (!line.empty()) {
                alllines.push_back(line);
            }
            break;
        } else if (ch == '\n') {
            alllines.push_back(line);
            line.clear();
        } else {
            line += static_cast<char>(ch);
        }
    }
}


void give_edge_in_sortedorder(list<string>&alllines,map<pair<int,int>,int> &edges,ofstream &writein)
{
    int no_edges=stoi(alllines.front());
    alllines.pop_front();
    map<pair<int,int>,int> mp;
    for(int i=0;i<no_edges;i++)
    {
        vector<int>t=getdata(alllines.front());
        alllines.pop_front();
        mp[{t[0],t[1]}]=t[2];
    }
    for (const auto& entry : mp) {
        const auto& key = entry.first;
        int value = entry.second;
        writein<<"e "<<key.first<<" "<<key.second<<" "<<value<<endl;
    }
    return;
}


int main(int argc ,char* argv[])
{
    string gr_ip=argv[1];
    FILE* inFile = fopen(gr_ip.c_str(), "r");
    list<string>alllines;
    string gr_op=argv[2];
    ofstream writein(gr_op);
    givealllines(inFile,alllines);
    map<string,int>vertex;
    int vertexco=0;
    while(1)
    {
        
        if(alllines.front()[0]=='#') 
         writein<<"t # "<<alllines.front().substr(1)<<endl;
        alllines.pop_front();
        int no_of_nodes=stoi(alllines.front());
        alllines.pop_front();
        
        for(int i=0;i<no_of_nodes;i++)
        {
            if(vertex.find(alllines.front())==vertex.end())
            {
                vertex[alllines.front()]=vertexco++;
            }
            string vid="";
            vid+="v "+to_string(i)+" "+to_string(vertex[alllines.front()]);
            writein<<vid<<endl;
            alllines.pop_front();

        }
        map<pair<int,int>,int> edges;
        give_edge_in_sortedorder(alllines,edges,writein);
        edges.clear();
        if(alllines.front().length()==0) alllines.pop_front();
        if(alllines.size()==0) break;

    }
    writein.close();
}
