       A2 � COL761
Team Details:
Team Name: Data_Voyagers
Github link: https://github.com/rajasekhar108/data_voyagers
Members:
Name           			Entry Number        Contribution
Bogam Sai Prabhath		2023AIB2079	     33.33
Mikshu Bhatt			2023AIB2067	     33.33
Nallavadla Rajasekhar Reddy	2023AIB2066          33.33





Files present inside the A2 folder in github
1. hw2_q1 folder consists of the files FOR question 1.
	a. fsg.exe
	b. gaston.exe
	c. gSpan-64.exe
	d. convertdata_fsg.cpp
	e. convertdata_gspan.cpp
	f. convertdata_gaston.cpp
	g. convertdatafsg.exe
	h. convertdatagspan.exe
	i. convertdatagaston.exe
	j. 167.txt_graph
	k. automate.sh
	l. plot.py
	m. output_graph.png
All the above files are bundled into a folder hw2_q1. d,e,f files are used to convert the data into required format for the algorithms. 
Upon running the automate.sh  <data_file_name> the code gets executed and AIB232079.png file of the plot will be generated. We used 167.txt_graph for generating the plot.
Libraries used: matplotlib

2. Hw2_q2 folder consists of the files for question 2:
	a. kmeans.py
	b. graph.sh
	c. AIB232079_generated_dataset_4D.dat
	c.generateDataset_d_dim_hpc_compiled
Upon running the file graph.sh  <dataset> <dimension> q3_<dimension>_< AIB232079>.png the datafile will be generated with the file name as AIB232079_generated_dataset_<dimension>D.dat and the same file should be given as the first argument in gragh.sh <dataset> then the kmeans code gets executed and elbow plot will be generated with the given output file name as q3_<dimension>_< AIB232079>.png.
Libraries used: matplotlib, sklearn


3. Report.pdf consists of explanation of all the 3 questions. Question3 explanation, pseudocode and complexity analysis is explained in report.pdf.
